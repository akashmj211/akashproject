# variables to store the file input values

data = {}
fin=[]
# reading data and store in fin list
with open("sample_input.txt") as f:
    
    for line in f:
       res=list(line.rstrip().split(":"))
       fin.append(res)
# removing 
for i in fin:
    if i[0] != "" and i[1]!="":
      
        data[i[0]]=int(i[1])


# sorting data dict using bubble sort
my_list = list(data.items())

for mx in range(len(my_list)-1, -1, -1):
    swapped = False
    for i in range(mx):
        if my_list[i][1] > my_list[i+1][1]:
            my_list[i], my_list[i+1] = my_list[i+1], my_list[i]
            swapped = True
    if not swapped:
        break

        

# storing input number of goodies
n=my_list[0][1]
# storing list of goddies
calc_data=my_list[1:]

min_d=0
res1=[]
res2=[]
final={}
for i in range(0,(len(calc_data)+1)-n):
    # selecting n goodies from sorted data
    res1=calc_data[i:i+n]
 
    # finding minimun value of the selected list
    min_d=res1[n-1][1]-res1[0][1]
    # appending the result to res2 list for furthur comparision
    res2.append(min_d)
    # storing the list with with diff key and value list
    final[min_d]=res1

# finding min value difference from list
min_res=min(res2)

# writing he file for appending result
output_file=open('sample_output.txt','w')

output_file.write("The goodies selected for distribution are:\n\n")

# fetcing the list of min diff value
final_list=final[min_res]

for i in final_list:
    output_file.write(str(i[0])+" : "+str(i[1])+'\n')

output_file.write("\nAnd the difference between the chosen goodie with highest price and the lowest price is "+str(min_res))

output_file.close()
# showing the output in the log
print("Minimun Difference",min_res)
for i in final_list:
    print(i[0],' : ',i[1],'\n')
print("Written in file sample_output.txt ")




